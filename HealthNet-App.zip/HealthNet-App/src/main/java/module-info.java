module com.example.healthnetapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.healthnetapp to javafx.fxml;
    exports com.example.healthnetapp;
}